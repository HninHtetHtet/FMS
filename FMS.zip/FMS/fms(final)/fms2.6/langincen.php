<?php

include "lang_en.php";
if($_POST){
		echo "<script>window.history.go(-1);</script>";
	}

?>