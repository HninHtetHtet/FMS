<?php
define("_behs", "B.E.H.S");
define("_bems", "B.E.M.S");

define("_REGISTER", "register");
define("_fname", "First Name");
define("_lname", "Last Name");
define("_getstart", "Get Started");
define("_address", "Address");
define("_address_txt", "University of Information Technology, Parami Road, Hlaing Campus, Yangon, Myanmar");
define("_school", "School");
define("_all", "All");
define("_yankin", "Yankin");
define("_ahlone","Ahlone");
define("_botahtaung", "Botahtaung");
define("_dagon", "Dagon");
define("_lanmadaw", "Lanmadaw");
define("_latha", "Latha");
define("_mingalardon", "Mingalardon");
define("_pabedan", "Pabedan");
define("_bahan", "Bahan");
define("_kamayut", "Kamayut");
define("_1","1");
define("_2","2");
define("_3","3");
define("_4","4");
define("_5","5");
define("_6","6");
define("_safety", "Safety");
define("_comfort", "Comfortable");
define("_reliable", "Reliable");
define("_design", "Web Design");
define("_performance", "Performance");
define("_phno", "09-123456");
define("_teammember", "Meet Our Team");
define("_cmk", "Chan Min Kyaw");
define("_zy", "Zayar Min Maung");
define("_km", "Khant Hmuu");
define("_igk", "Ingyin Khin");
define("_mmk", "Myo Myo Khant");
define("_hhh", "Hnin Htet Htet");
define("_outclient", "Our Happy Clients");

define("_location", "Location");
define("_email", "E-mail");
define("_sub", "Sub");
define("_message", "Message");
define("_send", "Send Message");
define("_onegivetrust", "One , gave our best for your trust");
define("_werfms", "Hello WE'RE FMS");

define("_setting", "Setting");
define("_lang","Language");
define("_myan","Myanmar");
define("_eng","English");
define("_lookvd","Watch Video");
define("_home","Home");
define("_about","About");
//define("_","Watch Video");
//define("_login","Watch Video");
define("_service", "Service");
define("_login", "Login");
define("_singup","SignUp");
define("_sign","SignUp");
define("_feedback","Feedback");
define("_contact", "Contact");
define("_fms", "WHAT IS FMS");
define("_fms_title_mean","WE ARE <strong>YOUR RELIABLE TEAM </strong>THAT THROWS YOUR INCONVENIENCE AWAY");
define("_fms_mean", "By using school bus for your children, you\"ll probably worried about transportation!Whether the school bus is directly locating to school or not or does everything synchronize with parents and owners or something like that!Yoou've been experienced those hurdles.");
define("_fms_mean1", "We came along for your convenience!Your trustworthy FMS!");
define("_create", "<strong>Creativity</strong> Is Our Passion");
define("_create_txt", "At first, we got the survey results that currently parents using school bus are in inconvenience by manual.So, we planned to design a platform that will cure the happenings they face lately and we got FMS!</p>
          <p>FMS longs for the school bus owners and parents feel more like convenience,even more like convenience!*Learn FMS </br>*Apply FMS</br>*Grab convenience & synchronization from FMS");
define("_meet_team", "Meet Our <strong>Team</strong>");
define("_meet_team_txt","You can know the base of FMS for your information freely.");
define("_cmk_txt", "Hello! one of the web-developers of the website! Very satisfied FMS appeared.WE NAILED IT!.
");
define("_hhh_txt","I've been in dynamic since started thinking about FMS.Welcome all! I'm an energetic web-developer.");
define("_igk_txt","Very content that I' am a part of this vigorous team as a web-developer.");

define("_km_txt","WhatUp!!Y'all are satisfied with web design,right? Here your graphic designer of FMS!!");

define("_mmk_txt","Hello everyone! I am a web-developer in FMS.Please long for the next projects of us!Thank You all!! ");
define("_zy_txt","I am a web-developer of FMS.As a leader of this team, I'm pleasaed as punch.Apply and review FMS to your heart contents.");
define("_about_fms","About FMS");
define("_about_fms_txt","Our intention is to provide convenient and easy ways to control and take care of your child (especially student) using new Technologies");
define("_contact_info", "Contact Info");
define("_ph", "Telephone");
define("_qlink", "Quick Links");
define("_gotq","Got a question? We love to hear from you.Send us message and we'll respond as soon as possible.");
define("_contact_info1", "<h2 class='mb-2 section-title' style='margin-top: -60px;'>Contact Info</h2>");
define("_name", "Name");
define("_school_txt", "We prefer you a good care of your children to reach to their school safely.");
define("_idea","Do You Have Something News In Mind?");
define("_idea_txt","If you have something to tell about our System , or your Satisfaction or Inconvenience , contact us everytime , please .");
define("_feedback_txt","Response from clients who used our system for their convenience.");
define("_aboutus","About Us");
define("_find_school","Find School");
define("_cli_fb","Client's Feedbacks");

define("_safety_txt","You can track your school bus location wherever you are now by GPS!");
define("_reliable_txt","Having problems with payment or kinda things?No longer catch out with those by using our website!");
define("_performance_txt","Not familiar with tech? Don't worry,here is y'all can easily catch the transaction on!");
define("_design_txt","Boring the plants off the complexity of web designs? Let's face it now at ease!");
define("_grab_txt","Have you ever thought about your school bus transportation you are already being a part of it?What sorts do you long for?Here Take them all to your environment! We are with you!</p>
    
    <p class='mb-5'>Your best school bus transportation is here!Why are you waiting for?Come join with us! ");
define("_service_ttt","The <strong>Services</strong> That We Are Providing");
define("_password","Password");
define("_enterpw","Enter password");
define("_enteremail","Enter email");
define("_forgetpw","Forget Password?");
define("_bktofms","Back to FMS");
define("_nrc","NRC");
define("_nrceg","NRC(eg.7/manyana(MNN)123456)..");
define("_dob","DOB");
define("_confirmpw","Confirm Password");
define('_submit', 'Submit');

?>