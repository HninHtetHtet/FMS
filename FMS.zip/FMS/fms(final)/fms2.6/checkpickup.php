<?php 
 
 echo $_GET['stuid'];
?>