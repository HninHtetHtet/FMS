<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form method="post" action="../aaa.php">
	
	<input type="text" name="name" value="Name">

	<input type="submit" name="submit" value="Submit">
</form>
</body>
</html>