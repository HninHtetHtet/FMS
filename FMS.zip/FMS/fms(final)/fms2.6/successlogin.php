
<!-- <?php 

$email=$_POST['email'];
?> -->
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/animate.css">
<link rel="stylesheet" type="text/css" href="css/successsignin.css">
<style type="text/css">

</style>
	
</head>
<body>

<div class="animated bounceIn errorsignin">
<h2>Welcome to FMS</h2>
<div class="errorimg"><img src="images/successnew.png" width="100px" height="100px"></div>
<div class="errtext">Register successfully</div>
<form action="landingpage.php" method="post">
<input type="submit" class="button" value="Login">
</form>
</div>

<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
</script>
</body>
</html>