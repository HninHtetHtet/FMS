   
    <!DOCTYPE HTML>
    <html>
    <head>
      <title>Driver_Dashboard</title>
    </head>
      <body>

        
          <div id="chartContainer" style="height: 370px; width: 100%;">
          
          




          </div>
   
  







   <div class="features clearfix">
     <div class="containerd">
        <div class="rowd">
            <div class="columns ten centered">
                <h2>View Your Excellent Drivers</h2>
            </div>
        </div>
      <div class="rowd">
         <div class="columns three">
            <section>
                <img src="images/admin.jpg" alt="">
                  <b>Gold</b>
                  <p>This driver got the best satisfaction among all from parents for this month.</p>
              </section>
          </div>
          <div class="columns three">
            <section>
                <img src="images/admin.jpg" alt="">
                <b>Silver</b>
                <p>This driver got the second best satisfaction among all from parents for this month.</p>
            </section>
        </div>
        <div class="rowd">
         <div class="columns three">
            <section>
                <img src="images/admin.jpg" alt="">
                  <b>Bronze</b>
                  <p>This driver got the third best satisfaction among all from parents for this month.</p>
              </section>
          </div>
        <div class="columns three">
            <section>
                <img src="images/admin.jpg" alt="">
                <b>Consolation</b>
                <p>This driver got the average satisfaction among all from parents for this month.</p>
            </section>
        </div>
        </div></div></div>

<link rel="stylesheet" href="css/driver_db.css">




      </body>
    </html>                              