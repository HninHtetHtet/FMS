<?php

// echo $_POST['name'];

echo "COnnected";

?>