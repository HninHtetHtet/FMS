<div class="bg-primary py-5">
    <div class="container text-center">
      <div class="row justify-content-center">
        <div class="col-lg-7">
          <h3 class="text-white mb-4 font-weight-normal"><?= _idea ?></h3>
          <p class="text-white mb-5"><?=  _idea_txt ?></p>

          <p class="mb-0"><a href="contactlanding.php" class="btn btn-outline-white px-4 py-3">Get In Touch!</a></p>
        </div>
      </div>

    </div>
  </div>